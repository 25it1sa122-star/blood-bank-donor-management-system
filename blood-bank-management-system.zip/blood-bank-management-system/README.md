# BloodConnect - Blood Bank Management System

Flask + MySQL + Bootstrap 5 web application with JWT authentication, role-based access (admin / donor),
blood stock management and a blood request workflow.

```
blood-bank-management-system/
├── frontend/            templates (Jinja2/HTML), static/css, static/js
├── backend/             Flask app, REST API routes, schema.sql, seed.sql, create_admin.py
├── .env.example
└── README.md
```

Flask serves both the pages and the API, so you only start **one** server.

---

## 1. Install the prerequisites (Windows)

1. **Python 3.10+** - https://www.python.org/downloads/ . On the first installer screen tick **"Add python.exe to PATH"**.
   Check: `python --version`
2. **MySQL Community Server 8.x** - https://dev.mysql.com/downloads/installer/ . During setup choose the
   **root** user with an **empty password** (this matches the development configuration; the installer may insist on a
   password - see the note in step 3). Make sure the **MySQL80** service is running (Win + R -> `services.msc`).
   Check: `mysql --version` (add `C:\Program Files\MySQL\MySQL Server 8.0\bin` to PATH if the command is not found).

## 2. Create the database and import the data

Open **Command Prompt** in the project folder (`cd` to `blood-bank-management-system`):

```bat
mysql -u root < backend\schema.sql
mysql -u root < backend\seed.sql
```

(If your root user has a password use `-p`: `mysql -u root -p < backend\schema.sql`.)

`schema.sql` creates the database `` `blood-bank-management-system` `` (the name has hyphens, so it is always quoted
with backticks), all tables, keys and constraints. `seed.sql` adds sample donors, stock and requests. Import
`seed.sql` only **once**; it inserts the sample requests every time it runs.

Quick check:

```bat
mysql -u root -e "SELECT blood_group, units FROM `blood-bank-management-system`.blood_stock"
```

> **Password note:** the project defaults to user `root` with an empty password for local development only. If your
> MySQL root has a password, put it in `.env` as `DB_PASSWORD`. Never use an empty root password on a real server.

## 3. Configure `.env`

```bat
copy .env.example .env
python -c "import secrets; print(secrets.token_hex(32))"
```

Run the second command twice, then open `.env` in Notepad and paste one value into `SECRET_KEY` and another into
`JWT_SECRET_KEY`. The database settings already default to:

```
DB_HOST=localhost
DB_PORT=3306
DB_USER=root
DB_PASSWORD=
DB_NAME=blood-bank-management-system
```

The app refuses to start while the secrets are still `change-me`.

## 4. Virtual environment and dependencies

```bat
cd backend
python -m venv venv
venv\Scripts\activate
pip install -r requirements.txt
```

(PowerShell: if activation is blocked, run `Set-ExecutionPolicy -Scope CurrentUser RemoteSigned` once, or use Command Prompt.)

## 5. Create the first administrator

There is no default admin password. Create the account with the script (the password is typed at a hidden prompt and
stored only as a Werkzeug hash):

```bat
python create_admin.py
```

## 6. Start the server and open the website

```bat
python app.py
```

Open **http://127.0.0.1:5000** in your browser. The terminal prints `[OK] Database connection OK` when MySQL is
reachable, or a clear **DATABASE SETUP ERROR** explaining what to fix (service not running, wrong password, database
missing, tables missing). `http://127.0.0.1:5000/api/health` shows the same check.

## 7. Try it out

| Step | What to do | Expected result |
|------|------------|-----------------|
| Login | `/login` with the admin you created | Redirect to Admin Dashboard with real counts |
| Donor registration | `/register`, fill the form | Account created, you land on *My Dashboard*; donor appears on `/donors` (name, group, city only) |
| Blood search | `/search-blood`, pick `O+` and a city | Stock for that group + matching donors (no phone/email shown) |
| Request blood | `/request-blood`, submit | Reference number shown; request is **Pending** |
| Approve | Admin -> **Requests** -> *Approve* | Status becomes **Approved**, stock unchanged |
| Fulfil | *Mark fulfilled* on an approved request | Stock for that group drops by the requested units, exactly once |
| Insufficient stock | Request more units than are in stock, approve, then fulfil | Clear "Insufficient stock" message; nothing is deducted |
| Stock update | Admin -> **Inventory**, use +5 or set an exact value | Homepage stock cards change; negative values are refused |

## Roles and security

- Passwords are hashed with Werkzeug; JWTs expire after `JWT_EXPIRES_MINUTES` (default 60) and every API call
  re-checks that the user still exists and is active.
- Donors can only view/edit/delete **their own** profile and see **their own** requests. Admins manage everything.
- Public pages show only blood group, city, availability and last donation date of **available** donors.
  Email, phone and address are visible only to the donor and admins.
- All SQL is parameterized; all input is validated on the server; CORS is limited to `CORS_ORIGINS`.
- Stock is changed only inside MySQL transactions with row locks (`SELECT ... FOR UPDATE`). A request can become
  **Fulfilled** once (final state), which is what guarantees stock is deducted once. Registering a donor never changes stock.
- Login attempts are throttled in memory (10 failures / 15 min per IP + email). This resets when the server restarts.

## REST API summary

| Method | Endpoint | Access |
|--------|----------|--------|
| POST | `/api/auth/register`, `/api/auth/login` | public |
| GET | `/api/auth/me` | logged in |
| GET | `/api/donors` | public (limited fields) / admin (full) |
| POST | `/api/donors` | admin |
| GET | `/api/donors/me` | donor |
| GET / PUT / DELETE | `/api/donors/:id` | owner or admin |
| GET | `/api/blood-stock` | public |
| PUT | `/api/blood-stock/:group` | admin (`{"units": 20}` or `{"adjust": -3}`) |
| POST | `/api/requests` | public / logged in |
| GET | `/api/requests`, `/api/requests/:id` | admin (all) / donor (own) |
| PATCH | `/api/requests/:id/status` | admin (`Approved`, `Rejected`, `Fulfilled`) |
| GET | `/api/admin/stats` | admin |
| GET | `/api/health` | public |

## Troubleshooting

- **"Cannot connect to MySQL"** - start the MySQL80 service; check `DB_HOST` / `DB_PORT`.
- **"MySQL rejected the login"** - fix `DB_USER` / `DB_PASSWORD` in `.env`.
- **"database does not exist" / "table is missing"** - re-run step 2.
- **`SECRET_KEY is missing`** - complete step 3.
- **Port 5000 busy** - change `PORT` in `.env`, and add the new origin to `CORS_ORIGINS`.
