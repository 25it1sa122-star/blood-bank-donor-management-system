/* BloodConnect front-end: talks to the Flask REST API. No secrets live here. */
(function () {
  "use strict";

  const GROUPS = ["A+", "A-", "B+", "B-", "AB+", "AB-", "O+", "O-"];

  // ------------------------------------------------------------ helpers
  const $ = (sel, root = document) => root.querySelector(sel);
  const $$ = (sel, root = document) => Array.from(root.querySelectorAll(sel));
  const esc = (v) => String(v ?? "").replace(/[&<>"']/g, (c) => (
    { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));

  const store = {
    get(k) { try { return localStorage.getItem(k); } catch (e) { return mem[k] || null; } },
    set(k, v) { try { localStorage.setItem(k, v); } catch (e) { mem[k] = v; } },
    del(k) { try { localStorage.removeItem(k); } catch (e) { delete mem[k]; } },
  };
  const mem = {};

  const auth = {
    token: () => store.get("bc_token"),
    user() { try { return JSON.parse(store.get("bc_user") || "null"); } catch (e) { return null; } },
    save(token, user) { store.set("bc_token", token); store.set("bc_user", JSON.stringify(user)); },
    clear() { store.del("bc_token"); store.del("bc_user"); },
  };

  function toast(message, type = "success") {
    const box = $("#toasts");
    if (!box) return;
    const cls = { success: "text-bg-success", error: "text-bg-danger", warning: "text-bg-warning" }[type] || "text-bg-secondary";
    const el = document.createElement("div");
    el.className = `toast align-items-center border-0 ${cls}`;
    el.setAttribute("role", "alert");
    el.innerHTML = `<div class="d-flex"><div class="toast-body">${esc(message)}</div>
      <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast" aria-label="Close"></button></div>`;
    box.appendChild(el);
    const t = new bootstrap.Toast(el, { delay: type === "error" ? 6500 : 4000 });
    el.addEventListener("hidden.bs.toast", () => el.remove());
    t.show();
  }

  function confirmDialog(title, body, okLabel = "Confirm", danger = false) {
    return new Promise((resolve) => {
      const modalEl = $("#confirmModal");
      $("#confirmTitle").textContent = title;
      $("#confirmBody").textContent = body;
      const ok = $("#confirmOk");
      ok.textContent = okLabel;
      ok.className = "btn " + (danger ? "btn-danger" : "btn-primary");
      const modal = bootstrap.Modal.getOrCreateInstance(modalEl);
      let answered = false;
      const onOk = () => { answered = true; modal.hide(); };
      const onHidden = () => { ok.removeEventListener("click", onOk); resolve(answered); };
      ok.addEventListener("click", onOk);
      modalEl.addEventListener("hidden.bs.modal", onHidden, { once: true });
      modal.show();
    });
  }

  async function api(path, { method = "GET", body, query } = {}) {
    let url = "/api" + path;
    if (query) {
      const qs = new URLSearchParams();
      Object.entries(query).forEach(([k, v]) => { if (v !== "" && v != null) qs.set(k, v); });
      const s = qs.toString();
      if (s) url += "?" + s;
    }
    const headers = {};
    if (body !== undefined) headers["Content-Type"] = "application/json";
    const token = auth.token();
    if (token) headers["Authorization"] = "Bearer " + token;

    let res;
    try {
      res = await fetch(url, { method, headers, body: body !== undefined ? JSON.stringify(body) : undefined });
    } catch (e) {
      showSetupBanner("Cannot reach the server. Make sure the Flask backend is running (python app.py).");
      throw { message: "Cannot reach the server.", status: 0 };
    }
    let data = {};
    try { data = await res.json(); } catch (e) { /* non-JSON */ }
    if (!res.ok) {
      if (data.setup_error) showSetupBanner(data.error);
      if (res.status === 401 && token && path !== "/auth/login") {
        auth.clear();
        if (!location.pathname.startsWith("/login")) {
          location.href = "/login?expired=1";
        }
      }
      throw { message: data.error || "Something went wrong.", fields: data.fields, status: res.status, data };
    }
    return data;
  }

  function showSetupBanner(msg) {
    const b = $("#setupBanner");
    if (!b) return;
    b.innerHTML = `<i class="bi bi-exclamation-triangle-fill me-1"></i><strong>Setup problem:</strong> ${esc(msg)}`;
    b.classList.remove("d-none");
  }

  function loading(el, text = "Loading...") {
    el.innerHTML = `<div class="loading-overlay"><div class="spinner-border spinner-red" role="status"></div>
      <div class="mt-2 small">${esc(text)}</div></div>`;
  }
  function empty(el, text, icon = "bi-inbox") {
    el.innerHTML = `<div class="empty-state"><i class="bi ${icon}"></i><div class="mt-2">${esc(text)}</div></div>`;
  }
  function errorBox(el, err) {
    el.innerHTML = `<div class="alert alert-danger mb-0"><i class="bi bi-x-octagon-fill me-1"></i>${esc(err.message || err)}</div>`;
  }

  const fmtDate = (s) => {
    if (!s) return "-";
    const d = new Date(String(s).length <= 10 ? s + "T00:00:00" : s);
    return isNaN(d) ? esc(s) : d.toLocaleDateString(undefined, { day: "2-digit", month: "short", year: "numeric" });
  };
  const statusBadge = (s) => `<span class="badge badge-status status-${esc(s)}">${esc(s)}</span>`;
  const urgencyBadge = (u) => `<span class="badge badge-status urg-${esc(u)}">${esc(u)}</span>`;

  function groupOptions(select, withAll = false, allLabel = "All blood groups") {
    select.innerHTML = (withAll ? `<option value="">${esc(allLabel)}</option>` : `<option value="">Select...</option>`) +
      GROUPS.map((g) => `<option value="${esc(g)}">${esc(g)}</option>`).join("");
  }

  // Generic form handling: client-side validation + server field errors
  function clearErrors(form) {
    $$(".is-invalid", form).forEach((e) => e.classList.remove("is-invalid"));
    $$(".invalid-feedback.dyn", form).forEach((e) => e.remove());
    const a = $(".form-alert", form);
    if (a) { a.className = "form-alert d-none"; a.textContent = ""; }
  }
  function showFieldErrors(form, fields) {
    Object.entries(fields || {}).forEach(([name, msg]) => {
      const input = form.elements[name];
      if (!input) return;
      input.classList.add("is-invalid");
      const fb = document.createElement("div");
      fb.className = "invalid-feedback dyn";
      fb.textContent = msg;
      input.insertAdjacentElement("afterend", fb);
    });
  }
  function formAlert(form, msg, type = "danger") {
    const a = $(".form-alert", form);
    if (!a) return toast(msg, type === "danger" ? "error" : "success");
    a.className = `form-alert alert alert-${type}`;
    a.textContent = msg;
  }
  function formData(form) {
    const out = {};
    Array.from(form.elements).forEach((el) => {
      if (!el.name || el.disabled) return;
      if (el.type === "checkbox") out[el.name] = el.checked;
      else out[el.name] = typeof el.value === "string" ? el.value.trim() : el.value;
    });
    return out;
  }
  function bindForm(form, handler) {
    if (!form) return;
    form.noValidate = true;
    form.addEventListener("submit", async (ev) => {
      ev.preventDefault();
      clearErrors(form);
      if (!form.checkValidity()) {
        form.classList.add("was-validated");
        const bad = form.querySelector(":invalid");
        if (bad) bad.focus();
        return;
      }
      const btn = $("button[type=submit]", form);
      const label = btn ? btn.innerHTML : "";
      if (btn) { btn.disabled = true; btn.innerHTML = `<span class="spinner-border spinner-border-sm me-1"></span>Please wait...`; }
      try {
        await handler(formData(form));
      } catch (err) {
        if (err && err.fields) showFieldErrors(form, err.fields);
        formAlert(form, (err && err.message) || "Something went wrong.");
      } finally {
        if (btn) { btn.disabled = false; btn.innerHTML = label; }
      }
    });
  }

  // ------------------------------------------------------------ navbar
  function renderNav() {
    const box = $("#navAuth");
    const user = auth.user();
    if (!box || !user) return;
    const dash = user.role === "admin" ? "/admin/dashboard" : "/donor/dashboard";
    box.innerHTML = `
      <a class="btn btn-outline-primary btn-sm" href="${dash}"><i class="bi bi-speedometer2 me-1"></i>${user.role === "admin" ? "Admin" : "My Dashboard"}</a>
      <button class="btn btn-primary btn-sm" id="logoutBtn"><i class="bi bi-box-arrow-right me-1"></i>Logout</button>`;
    $("#logoutBtn").addEventListener("click", () => { auth.clear(); location.href = "/login?loggedout=1"; });
  }

  function requireRole(role) {
    const user = auth.user();
    if (!user || !auth.token()) { location.href = "/login?next=" + encodeURIComponent(location.pathname); return false; }
    if (role && user.role !== role) {
      location.href = user.role === "admin" ? "/admin/dashboard" : "/donor/dashboard";
      return false;
    }
    return true;
  }

  function adminTabs(active) {
    const el = $("#adminTabs");
    if (!el) return;
    const tabs = [["dash", "/admin/dashboard", "bi-speedometer2", "Dashboard"],
      ["donors", "/admin/donors", "bi-people", "Donors"],
      ["requests", "/admin/requests", "bi-clipboard2-pulse", "Requests"],
      ["stock", "/admin/stock", "bi-droplet-half", "Inventory"]];
    el.innerHTML = tabs.map(([k, href, icon, label]) =>
      `<li class="nav-item"><a class="nav-link ${k === active ? "active" : ""}" href="${href}"><i class="bi ${icon} me-1"></i>${label}</a></li>`).join("");
  }

  // ------------------------------------------------------------ shared renderers
  function stockCards(stock, target) {
    target.innerHTML = stock.map((s) => {
      const cls = s.units === 0 ? "stock-out" : s.units < 5 ? "stock-low" : "";
      const label = s.units === 0 ? "Out of stock" : s.units < 5 ? "Low stock" : "units available";
      return `<div class="col-6 col-md-3"><div class="bc-card stock-card ${cls}">
        <span class="group">${esc(s.blood_group)}</span>
        <div class="units">${esc(s.units)}</div><div class="label">${label}</div></div></div>`;
    }).join("");
  }

  function donorCards(donors, target, admin = false) {
    if (!donors.length) return empty(target, "No donors match your search.", "bi-people");
    target.innerHTML = `<div class="row g-3">${donors.map((d) => `
      <div class="col-md-6 col-lg-4"><div class="bc-card donor-card">
        <div class="d-flex gap-3 align-items-start">
          <div class="group">${esc(d.blood_group)}</div>
          <div class="flex-grow-1">
            <div class="fw-semibold">${esc(d.full_name)}</div>
            <div class="small text-muted"><i class="bi bi-geo-alt me-1"></i>${esc(d.city)}</div>
            <div class="small mt-1">
              ${d.eligible ? '<span class="badge text-bg-success">Available to donate</span>'
                : d.is_available ? '<span class="badge text-bg-warning">Recently donated</span>'
                : '<span class="badge text-bg-secondary">Unavailable</span>'}
            </div>
            <div class="small text-muted mt-1">Last donation: ${fmtDate(d.last_donation_date)}</div>
          </div>
        </div></div></div>`).join("")}</div>`;
  }

  function requestRows(list, { admin = false } = {}) {
    return list.map((r) => {
      let actions = "";
      if (admin) {
        if (r.status === "Pending") {
          actions = `<button class="btn btn-sm btn-success me-1" data-act="Approved" data-id="${r.id}">Approve</button>
                     <button class="btn btn-sm btn-outline-danger" data-act="Rejected" data-id="${r.id}">Reject</button>`;
        } else if (r.status === "Approved") {
          actions = `<button class="btn btn-sm btn-primary me-1" data-act="Fulfilled" data-id="${r.id}">Mark fulfilled</button>
                     <button class="btn btn-sm btn-outline-danger" data-act="Rejected" data-id="${r.id}">Reject</button>`;
        } else actions = '<span class="text-muted small">Final</span>';
      }
      return `<tr>
        <td>#${r.id}</td>
        <td><div class="fw-semibold">${esc(r.patient_name)}</div>
            <div class="small text-muted">${esc(r.contact_number)}</div></td>
        <td><span class="badge text-bg-danger">${esc(r.blood_group)}</span> &times; ${esc(r.units)}</td>
        <td>${esc(r.hospital_name)}<div class="small text-muted">${esc(r.city)}</div></td>
        <td>${urgencyBadge(r.urgency)}</td>
        <td>${fmtDate(r.request_date)}</td>
        <td>${statusBadge(r.status)}${r.admin_note ? `<div class="small text-muted">${esc(r.admin_note)}</div>` : ""}</td>
        ${admin ? `<td class="text-nowrap">${actions}</td>` : ""}</tr>`;
    }).join("");
  }

  function requestTable(list, opts = {}) {
    return `<div class="table-responsive"><table class="table table-bc table-hover mb-0">
      <thead><tr><th>ID</th><th>Patient</th><th>Blood</th><th>Hospital</th><th>Urgency</th><th>Needed by</th><th>Status</th>${opts.admin ? "<th>Actions</th>" : ""}</tr></thead>
      <tbody>${requestRows(list, opts)}</tbody></table></div>`;
  }

  async function changeStatus(id, status, reload) {
    const verbs = { Approved: "approve", Rejected: "reject", Fulfilled: "mark as fulfilled" };
    const extra = status === "Fulfilled" ? " The requested units will be deducted from stock (once)." : "";
    const ok = await confirmDialog(`${status === "Rejected" ? "Reject" : "Update"} request #${id}`,
      `Are you sure you want to ${verbs[status]} this request?${extra}`, "Yes, continue", status === "Rejected");
    if (!ok) return;
    try {
      const res = await api(`/requests/${id}/status`, { method: "PATCH", body: { status } });
      toast(res.message);
      if (res.warning) toast(res.warning, "warning");
      reload();
    } catch (e) { toast(e.message, "error"); }
  }

  // ------------------------------------------------------------ pages
  const pages = {};

  pages.home = async () => {
    const stockBox = $("#stockCards");
    loading(stockBox);
    try {
      const { stock } = await api("/blood-stock");
      stockCards(stock, stockBox);
      stockBox.classList.add("row", "g-3");
    } catch (e) { errorBox(stockBox, e); }
    groupOptions($("#homeGroup"), true, "Any blood group");
    $("#homeSearch").addEventListener("submit", (ev) => {
      ev.preventDefault();
      const qs = new URLSearchParams();
      if ($("#homeGroup").value) qs.set("blood_group", $("#homeGroup").value);
      if ($("#homeCity").value.trim()) qs.set("city", $("#homeCity").value.trim());
      location.href = "/search-blood?" + qs;
    });
  };

  pages.login = () => {
    const q = new URLSearchParams(location.search);
    const note = $("#loginNote");
    if (q.get("expired")) { note.textContent = "Your session expired. Please log in again."; note.classList.remove("d-none"); }
    if (q.get("loggedout")) { note.textContent = "You have been logged out."; note.classList.remove("d-none"); }
    if (q.get("registered")) { note.textContent = "Registration complete."; note.classList.remove("d-none"); }
    bindForm($("#loginForm"), async (d) => {
      const res = await api("/auth/login", { method: "POST", body: { email: d.email, password: d.password } });
      auth.save(res.token, res.user);
      const next = q.get("next");
      const safeNext = next && next.startsWith("/") && !next.startsWith("//") ? next : null;
      location.href = safeNext || (res.user.role === "admin" ? "/admin/dashboard" : "/donor/dashboard");
    });
  };

  pages.register = () => {
    groupOptions($("#regGroup"));
    bindForm($("#registerForm"), async (d) => {
      if (d.password !== d.confirm_password) {
        throw { message: "Passwords do not match.", fields: { confirm_password: "Passwords do not match." } };
      }
      const body = { ...d };
      delete body.confirm_password;
      body.age = parseInt(body.age, 10);
      body.last_donation_date = body.last_donation_date || null;
      const res = await api("/auth/register", { method: "POST", body });
      auth.save(res.token, res.user);
      toast("Welcome to BloodConnect! Thank you for registering.");
      setTimeout(() => (location.href = "/donor/dashboard"), 700);
    });
  };

  pages.donors = () => {
    groupOptions($("#fGroup"), true);
    const list = $("#donorList");
    const load = async () => {
      loading(list, "Finding donors...");
      try {
        const res = await api("/donors", { query: { blood_group: $("#fGroup").value, city: $("#fCity").value.trim() } });
        $("#donorCount").textContent = `${res.total} donor${res.total === 1 ? "" : "s"} found`;
        donorCards(res.donors, list);
      } catch (e) { errorBox(list, e); }
    };
    $("#donorFilter").addEventListener("submit", (ev) => { ev.preventDefault(); load(); });
    load();
  };

  pages.search = async () => {
    const q = new URLSearchParams(location.search);
    groupOptions($("#sGroup"), true, "Any blood group");
    $("#sGroup").value = q.get("blood_group") || "";
    $("#sCity").value = q.get("city") || "";
    const stockBox = $("#searchStock");
    const result = $("#searchResult");

    const loadStock = async () => {
      try {
        const { stock } = await api("/blood-stock");
        stockCards(stock, stockBox);
        return stock;
      } catch (e) { errorBox(stockBox, e); return []; }
    };
    const run = async () => {
      const group = $("#sGroup").value;
      loading(result, "Searching...");
      const stock = await loadStock();
      let html = "";
      if (group) {
        const s = stock.find((x) => x.blood_group === group);
        const units = s ? s.units : 0;
        html += units > 0
          ? `<div class="alert alert-success"><i class="bi bi-check-circle-fill me-1"></i><strong>${units}</strong> unit(s) of <strong>${esc(group)}</strong> are in the blood bank.
             <a href="/request-blood?blood_group=${encodeURIComponent(group)}" class="alert-link ms-1">Request this blood</a></div>`
          : `<div class="alert alert-warning"><i class="bi bi-exclamation-triangle-fill me-1"></i>No <strong>${esc(group)}</strong> units in stock right now. You can still
             <a href="/request-blood?blood_group=${encodeURIComponent(group)}" class="alert-link">place a request</a> or contact a donor below.</div>`;
      }
      try {
        const res = await api("/donors", { query: { blood_group: group, city: $("#sCity").value.trim() } });
        html += `<h5 class="mb-3">Matching donors <span class="text-muted fs-6">(${res.total})</span></h5><div id="searchDonors"></div>`;
        result.innerHTML = html;
        donorCards(res.donors, $("#searchDonors"));
        const note = document.createElement("p");
        note.className = "small text-muted mt-3";
        note.innerHTML = '<i class="bi bi-shield-lock me-1"></i>Donor contact details are private. Submit a blood request and our team will coordinate.';
        result.appendChild(note);
      } catch (e) { result.innerHTML = html; const d = document.createElement("div"); result.appendChild(d); errorBox(d, e); }
    };
    $("#searchForm").addEventListener("submit", (ev) => { ev.preventDefault(); run(); });
    run();
  };

  pages.request = () => {
    const q = new URLSearchParams(location.search);
    groupOptions($("#reqGroup"));
    if (q.get("blood_group")) $("#reqGroup").value = q.get("blood_group");
    if (q.get("urgency")) $("#reqUrgency").value = q.get("urgency");
    const today = new Date().toISOString().slice(0, 10);
    $("#reqDate").min = today;
    $("#reqDate").value = today;
    bindForm($("#requestForm"), async (d) => {
      d.units = parseInt(d.units, 10);
      const res = await api("/requests", { method: "POST", body: d });
      toast(res.message);
      $("#requestForm").reset();
      $("#reqDate").value = today;
      $("#requestForm").classList.remove("was-validated");
      const ok = $("#reqSuccess");
      ok.classList.remove("d-none");
      ok.innerHTML = `<i class="bi bi-check-circle-fill me-1"></i>${esc(res.message)} Your reference number is <strong>#${res.request.id}</strong>.`;
      ok.scrollIntoView({ behavior: "smooth", block: "center" });
    });
  };

  pages["donor-dashboard"] = async () => {
    if (!requireRole("donor")) return;
    groupOptions($("#pGroup"));
    const form = $("#profileForm");
    let donor = null;
    const fill = (d) => {
      Object.entries({ full_name: d.full_name, email: d.email, phone: d.phone, blood_group: d.blood_group,
        city: d.city, address: d.address, age: d.age, last_donation_date: d.last_donation_date || "" })
        .forEach(([k, v]) => { if (form.elements[k]) form.elements[k].value = v; });
      form.elements.is_available.checked = !!d.is_available;
      $("#eligBadge").innerHTML = d.eligible
        ? '<span class="badge text-bg-success">Eligible to donate now</span>'
        : '<span class="badge text-bg-warning">Not eligible right now</span>';
    };
    try {
      donor = (await api("/donors/me")).donor;
      fill(donor);
      $("#welcomeName").textContent = donor.full_name;
    } catch (e) { formAlert(form, e.message); }

    bindForm(form, async (d) => {
      d.age = parseInt(d.age, 10);
      d.last_donation_date = d.last_donation_date || null;
      const res = await api(`/donors/${donor.id}`, { method: "PUT", body: d });
      donor = res.donor;
      fill(donor);
      const u = auth.user();
      if (u) { u.full_name = donor.full_name; u.email = donor.email; auth.save(auth.token(), u); }
      toast(res.message);
    });

    $("#deleteAccount").addEventListener("click", async () => {
      if (!donor) return;
      const ok = await confirmDialog("Delete my account", "This permanently deletes your donor profile and login. This cannot be undone.", "Delete permanently", true);
      if (!ok) return;
      try {
        await api(`/donors/${donor.id}`, { method: "DELETE" });
        auth.clear();
        location.href = "/?deleted=1";
      } catch (e) { toast(e.message, "error"); }
    });

    const box = $("#myRequests");
    loading(box);
    try {
      const { requests } = await api("/requests");
      if (!requests.length) empty(box, "You have not submitted any blood requests yet.", "bi-clipboard2");
      else box.innerHTML = requestTable(requests);
    } catch (e) { errorBox(box, e); }
  };

  pages["admin-dashboard"] = async () => {
    if (!requireRole("admin")) return;
    adminTabs("dash");
    const wrap = $("#dashBody");
    loading(wrap, "Loading dashboard...");
    const load = async () => {
      let s;
      try { s = await api("/admin/stats"); } catch (e) { return errorBox(wrap, e); }
      const stat = (icon, value, name) => `<div class="col-6 col-lg-3"><div class="bc-card stat-card">
        <div class="icon-circle"><i class="bi ${icon}"></i></div><div><div class="value">${value}</div><div class="name">${name}</div></div></div></div>`;
      const maxD = Math.max(1, ...Object.values(s.reports.donors_by_group));
      const maxS = Math.max(1, ...s.stock.map((x) => x.units));
      wrap.innerHTML = `
        <div class="row g-3 mb-4">
          ${stat("bi-people-fill", s.total_donors, "Registered donors")}
          ${stat("bi-droplet-fill", s.total_units, "Blood units available")}
          ${stat("bi-hourglass-split", s.pending_requests, "Pending requests")}
          ${stat("bi-check2-circle", s.approved_requests, "Approved requests")}
          ${stat("bi-x-circle", s.rejected_requests, "Rejected requests")}
          ${stat("bi-bag-check-fill", s.fulfilled_requests, "Fulfilled requests")}
          ${stat("bi-person-check-fill", s.available_donors, "Available donors")}
          ${stat("bi-clipboard2-data", s.total_requests, "Total requests")}
        </div>
        ${s.low_stock_groups.length ? `<div class="alert alert-warning"><i class="bi bi-exclamation-triangle-fill me-1"></i>Low stock (under 5 units): <strong>${s.low_stock_groups.map(esc).join(", ")}</strong>. <a href="/admin/stock" class="alert-link">Update inventory</a></div>` : ""}
        <div class="row g-4 mb-4">
          <div class="col-lg-6"><div class="bc-card p-3 h-100">
            <div class="d-flex justify-content-between align-items-center mb-3"><h5 class="mb-0">Blood group inventory</h5><a href="/admin/stock" class="small">Manage</a></div>
            ${s.stock.map((x) => `<div class="bar-row"><span class="lbl">${esc(x.blood_group)}</span><div class="bar"><span style="width:${(x.units / maxS) * 100}%"></span></div><span class="num">${x.units}</span></div>`).join("")}
          </div></div>
          <div class="col-lg-6"><div class="bc-card p-3 h-100">
            <h5 class="mb-3">Reports &amp; statistics</h5>
            <div class="small text-muted mb-1">Donors by blood group</div>
            ${GROUPS.map((g) => `<div class="bar-row"><span class="lbl">${esc(g)}</span><div class="bar"><span style="width:${(s.reports.donors_by_group[g] / maxD) * 100}%"></span></div><span class="num">${s.reports.donors_by_group[g]}</span></div>`).join("")}
            <hr><div class="row small">
              <div class="col-6"><div class="text-muted">Units fulfilled to date</div><div class="fs-5 fw-bold">${s.reports.units_fulfilled}</div></div>
              <div class="col-6"><div class="text-muted">Top donor cities</div>${s.reports.top_cities.map((c) => `${esc(c.city)} (${c.donors})`).join(", ") || "-"}</div>
            </div>
          </div></div>
        </div>
        <div class="bc-card p-3">
          <div class="d-flex justify-content-between align-items-center mb-3"><h5 class="mb-0">Recent blood requests</h5><a href="/admin/requests" class="small">View all</a></div>
          ${s.recent_requests.length ? `<div class="table-responsive"><table class="table table-bc mb-0"><thead><tr><th>ID</th><th>Patient</th><th>Blood</th><th>Hospital</th><th>Urgency</th><th>Status</th></tr></thead><tbody>
            ${s.recent_requests.map((r) => `<tr><td>#${r.id}</td><td>${esc(r.patient_name)}</td><td><span class="badge text-bg-danger">${esc(r.blood_group)}</span> &times; ${r.units}</td><td>${esc(r.hospital_name)}, ${esc(r.city)}</td><td>${urgencyBadge(r.urgency)}</td><td>${statusBadge(r.status)}</td></tr>`).join("")}
          </tbody></table></div>` : '<div class="empty-state">No requests yet.</div>'}
        </div>`;
    };
    load();
  };

  pages["manage-donors"] = async () => {
    if (!requireRole("admin")) return;
    adminTabs("donors");
    groupOptions($("#mGroup"), true);
    groupOptions($("#dGroup"));
    const body = $("#donorRows");
    const modalEl = $("#donorModal");
    const modal = new bootstrap.Modal(modalEl);
    const form = $("#donorForm");
    let editingId = null;

    const load = async () => {
      loading(body, "Loading donors...");
      try {
        const res = await api("/donors", { query: {
          blood_group: $("#mGroup").value, city: $("#mCity").value.trim(),
          q: $("#mQ").value.trim(), available: $("#mAvail").value, per_page: 100 } });
        $("#donorTotal").textContent = res.total;
        if (!res.donors.length) return empty(body, "No donors found.", "bi-people");
        body.innerHTML = `<div class="table-responsive"><table class="table table-bc table-hover mb-0"><thead><tr>
          <th>Name</th><th>Blood</th><th>Contact</th><th>City</th><th>Age</th><th>Last donation</th><th>Status</th><th></th></tr></thead><tbody>
          ${res.donors.map((d) => `<tr>
            <td class="fw-semibold">${esc(d.full_name)}</td>
            <td><span class="badge text-bg-danger">${esc(d.blood_group)}</span></td>
            <td><div class="small">${esc(d.email)}</div><div class="small text-muted">${esc(d.phone)}</div></td>
            <td>${esc(d.city)}</td><td>${d.age}</td><td>${fmtDate(d.last_donation_date)}</td>
            <td>${d.is_available ? '<span class="badge text-bg-success">Available</span>' : '<span class="badge text-bg-secondary">Unavailable</span>'}</td>
            <td class="text-nowrap">
              <button class="btn btn-sm btn-outline-primary me-1" data-edit="${d.id}"><i class="bi bi-pencil"></i></button>
              <button class="btn btn-sm btn-outline-danger" data-del="${d.id}" data-name="${esc(d.full_name)}"><i class="bi bi-trash"></i></button>
            </td></tr>`).join("")}</tbody></table></div>`;
        body._donors = res.donors;
      } catch (e) { errorBox(body, e); }
    };

    const openModal = (donor) => {
      clearErrors(form); form.classList.remove("was-validated"); form.reset();
      editingId = donor ? donor.id : null;
      $("#donorModalTitle").textContent = donor ? "Edit donor" : "Add donor";
      if (donor) {
        ["full_name", "email", "phone", "blood_group", "city", "address", "age"].forEach((k) => (form.elements[k].value = donor[k]));
        form.elements.last_donation_date.value = donor.last_donation_date || "";
        form.elements.is_available.checked = !!donor.is_available;
      } else form.elements.is_available.checked = true;
      modal.show();
    };

    $("#addDonorBtn").addEventListener("click", () => openModal(null));
    $("#donorFilter").addEventListener("submit", (ev) => { ev.preventDefault(); load(); });
    body.addEventListener("click", async (ev) => {
      const edit = ev.target.closest("[data-edit]");
      const del = ev.target.closest("[data-del]");
      if (edit) openModal((body._donors || []).find((d) => d.id === +edit.dataset.edit));
      if (del) {
        const ok = await confirmDialog("Delete donor", `Delete ${del.dataset.name}? This removes the donor record (and login, if any) permanently.`, "Delete", true);
        if (!ok) return;
        try { toast((await api(`/donors/${del.dataset.del}`, { method: "DELETE" })).message); load(); }
        catch (e) { toast(e.message, "error"); }
      }
    });
    bindForm(form, async (d) => {
      d.age = parseInt(d.age, 10);
      d.last_donation_date = d.last_donation_date || null;
      const res = editingId
        ? await api(`/donors/${editingId}`, { method: "PUT", body: d })
        : await api("/donors", { method: "POST", body: d });
      toast(res.message);
      modal.hide();
      load();
    });
    load();
  };

  pages["manage-requests"] = async () => {
    if (!requireRole("admin")) return;
    adminTabs("requests");
    groupOptions($("#rGroup"), true);
    const box = $("#requestList");
    const load = async () => {
      loading(box, "Loading requests...");
      try {
        const res = await api("/requests", { query: { status: $("#rStatus").value, blood_group: $("#rGroup").value, q: $("#rQ").value.trim(), per_page: 100 } });
        $("#requestTotal").textContent = res.total;
        if (!res.requests.length) return empty(box, "No requests match your filters.", "bi-clipboard2");
        box.innerHTML = requestTable(res.requests, { admin: true });
      } catch (e) { errorBox(box, e); }
    };
    $("#requestFilter").addEventListener("submit", (ev) => { ev.preventDefault(); load(); });
    box.addEventListener("click", (ev) => {
      const b = ev.target.closest("[data-act]");
      if (b) changeStatus(+b.dataset.id, b.dataset.act, load);
    });
    load();
  };

  pages["blood-stock"] = async () => {
    if (!requireRole("admin")) return;
    adminTabs("stock");
    const box = $("#stockTable");
    const load = async () => {
      loading(box);
      try {
        const { stock, total_units } = await api("/blood-stock");
        $("#totalUnits").textContent = total_units;
        box.innerHTML = `<div class="table-responsive"><table class="table table-bc align-middle mb-0"><thead><tr>
          <th>Blood group</th><th>Units available</th><th>Quick adjust</th><th style="min-width:230px">Set exact amount</th></tr></thead><tbody>
          ${stock.map((s) => `<tr data-group="${esc(s.blood_group)}">
            <td><span class="badge text-bg-danger fs-6">${esc(s.blood_group)}</span></td>
            <td class="fw-bold fs-5">${s.units}${s.units < 5 ? ' <span class="badge text-bg-warning ms-1">Low</span>' : ""}</td>
            <td class="text-nowrap">
              <button class="btn btn-sm btn-outline-primary" data-adj="-1">-1</button>
              <button class="btn btn-sm btn-outline-primary" data-adj="1">+1</button>
              <button class="btn btn-sm btn-outline-primary" data-adj="5">+5</button>
              <button class="btn btn-sm btn-outline-primary" data-adj="10">+10</button></td>
            <td><div class="input-group input-group-sm"><input type="number" min="0" max="100000" class="form-control" value="${s.units}" aria-label="Units for ${esc(s.blood_group)}">
              <button class="btn btn-primary" data-set="1">Save</button></div></td></tr>`).join("")}</tbody></table></div>`;
      } catch (e) { errorBox(box, e); }
    };
    box.addEventListener("click", async (ev) => {
      const row = ev.target.closest("tr[data-group]");
      if (!row) return;
      const group = row.dataset.group;
      let body = null;
      if (ev.target.dataset.adj) body = { adjust: parseInt(ev.target.dataset.adj, 10) };
      if (ev.target.dataset.set) {
        const v = row.querySelector("input").value;
        if (v === "" || !/^\d+$/.test(v)) return toast("Enter a whole number, zero or more.", "error");
        const ok = await confirmDialog("Set stock", `Set ${group} stock to exactly ${v} unit(s)?`);
        if (!ok) return;
        body = { units: parseInt(v, 10) };
      }
      if (!body) return;
      try {
        const res = await api(`/blood-stock/${encodeURIComponent(group)}`, { method: "PUT", body });
        toast(res.message);
        load();
      } catch (e) { toast(e.message, "error"); }
    });
    load();
  };

  // ------------------------------------------------------------ boot
  document.addEventListener("DOMContentLoaded", () => {
    const y = $("#year"); if (y) y.textContent = new Date().getFullYear();
    renderNav();
    const page = document.body.dataset.page;
    if (location.search.includes("deleted=1") && page === "home") toast("Your account has been deleted.");
    if (pages[page]) pages[page]();
  });
})();
