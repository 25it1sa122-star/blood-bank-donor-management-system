-- Sample data for development. Import ONCE, after schema.sql.
-- Sample donors have no login account (user_id is NULL). Create the admin with create_admin.py.

USE `blood-bank-management-system`;

-- Blood inventory (the 8 rows already exist from schema.sql)
UPDATE blood_stock SET units = 24 WHERE blood_group = 'A+';
UPDATE blood_stock SET units = 6  WHERE blood_group = 'A-';
UPDATE blood_stock SET units = 31 WHERE blood_group = 'B+';
UPDATE blood_stock SET units = 8  WHERE blood_group = 'B-';
UPDATE blood_stock SET units = 12 WHERE blood_group = 'AB+';
UPDATE blood_stock SET units = 3  WHERE blood_group = 'AB-';
UPDATE blood_stock SET units = 42 WHERE blood_group = 'O+';
UPDATE blood_stock SET units = 9  WHERE blood_group = 'O-';

-- Donors
INSERT IGNORE INTO donors
  (full_name, email, phone, blood_group, city, address, age, last_donation_date, is_available)
VALUES
  ('Aarav Sharma',   'aarav.sharma@example.com',   '9876543210', 'O+',  'Mumbai',    '12 Linking Road, Bandra West',        28, CURDATE() - INTERVAL 150 DAY, 1),
  ('Priya Nair',     'priya.nair@example.com',     '9876501234', 'A+',  'Bengaluru', '45 MG Road, Indiranagar',             34, CURDATE() - INTERVAL 200 DAY, 1),
  ('Rohan Mehta',    'rohan.mehta@example.com',    '9812345670', 'B+',  'Delhi',     '8 Connaught Place',                   41, CURDATE() - INTERVAL 40 DAY,  0),
  ('Sneha Iyer',     'sneha.iyer@example.com',     '9823456781', 'AB+', 'Chennai',   '22 Anna Salai, T Nagar',              26, NULL,                         1),
  ('Vikram Singh',   'vikram.singh@example.com',   '9834567892', 'O-',  'Mumbai',    '77 Andheri East',                     37, CURDATE() - INTERVAL 120 DAY, 1),
  ('Ananya Reddy',   'ananya.reddy@example.com',   '9845678903', 'B-',  'Hyderabad', '5 Banjara Hills Road No 3',           30, CURDATE() - INTERVAL 95 DAY,  1),
  ('Karthik Rao',    'karthik.rao@example.com',    '9856789014', 'A-',  'Bengaluru', '19 Koramangala 4th Block',            45, CURDATE() - INTERVAL 300 DAY, 1),
  ('Meera Pillai',   'meera.pillai@example.com',   '9867890125', 'AB-', 'Kochi',     '3 Marine Drive',                      32, CURDATE() - INTERVAL 180 DAY, 1),
  ('Arjun Verma',    'arjun.verma@example.com',    '9878901236', 'O+',  'Delhi',     '14 Lajpat Nagar II',                  24, CURDATE() - INTERVAL 60 DAY,  1),
  ('Divya Gupta',    'divya.gupta@example.com',    '9889012347', 'B+',  'Pune',      '31 Koregaon Park',                    29, CURDATE() - INTERVAL 110 DAY, 1),
  ('Suresh Kumar',   'suresh.kumar@example.com',   '9890123458', 'A+',  'Chennai',   '60 Adyar Main Road',                  50, CURDATE() - INTERVAL 400 DAY, 1),
  ('Neha Joshi',     'neha.joshi@example.com',     '9801234569', 'O+',  'Pune',      '9 FC Road, Shivajinagar',             27, CURDATE() - INTERVAL 130 DAY, 1);

-- Blood requests (status mix so every dashboard counter has real data)
INSERT INTO blood_requests
  (patient_name, blood_group, units, hospital_name, city, contact_number, urgency, request_date, status, admin_note, fulfilled_at)
VALUES
  ('Ramesh Patil',   'O-',  2, 'City General Hospital',   'Mumbai',    '9900112233', 'Critical', CURDATE(),                   'Pending',   NULL, NULL),
  ('Lakshmi Devi',   'B+',  3, 'Apollo Hospital',         'Chennai',   '9900223344', 'Urgent',   CURDATE(),                   'Pending',   NULL, NULL),
  ('Mohan Das',      'A+',  2, 'Fortis Hospital',         'Delhi',     '9900334455', 'Normal',   CURDATE() - INTERVAL 1 DAY,  'Approved',  'Approved, awaiting collection', NULL),
  ('Farah Khan',     'AB-', 5, 'Manipal Hospital',        'Bengaluru', '9900445566', 'Urgent',   CURDATE() - INTERVAL 2 DAY,  'Rejected',  'Insufficient AB- stock at the time', NULL),
  ('Joseph Thomas',  'O+',  2, 'Aster Medcity',           'Kochi',     '9900556677', 'Normal',   CURDATE() - INTERVAL 5 DAY,  'Fulfilled', 'Collected by hospital', NOW() - INTERVAL 4 DAY),
  ('Sunita Rao',     'B-',  1, 'Yashoda Hospital',        'Hyderabad', '9900667788', 'Normal',   CURDATE() - INTERVAL 8 DAY,  'Fulfilled', 'Collected by relative', NOW() - INTERVAL 7 DAY),
  ('Imran Sheikh',   'A-',  2, 'Ruby Hall Clinic',        'Pune',      '9900778899', 'Urgent',   CURDATE() - INTERVAL 3 DAY,  'Approved',  NULL, NULL);
