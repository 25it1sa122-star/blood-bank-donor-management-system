"""Application configuration. All secrets come from environment variables / .env."""
import os
from pathlib import Path

from dotenv import load_dotenv

BASE_DIR = Path(__file__).resolve().parent
PROJECT_DIR = BASE_DIR.parent

# .env lives in the project root (next to .env.example)
load_dotenv(PROJECT_DIR / ".env")


class ConfigError(RuntimeError):
    """Raised when a required setting is missing or still a placeholder."""


def _secret(name: str) -> str:
    value = os.getenv(name, "").strip()
    if not value or value.lower().startswith("change-me"):
        raise ConfigError(
            f"{name} is missing or still set to the placeholder value.\n"
            f"Open your .env file and set {name} to a long random string. Generate one with:\n"
            f'    python -c "import secrets; print(secrets.token_hex(32))"'
        )
    return value


class Config:
    # Database (defaults match the local development setup)
    DB_HOST = os.getenv("DB_HOST", "localhost")
    DB_PORT = int(os.getenv("DB_PORT", "3306"))
    DB_USER = os.getenv("DB_USER", "root")
    DB_PASSWORD = os.getenv("DB_PASSWORD", "")
    DB_NAME = os.getenv("DB_NAME", "blood-bank-management-system")

    # Secrets (required)
    SECRET_KEY = _secret("SECRET_KEY")
    JWT_SECRET_KEY = _secret("JWT_SECRET_KEY")
    JWT_ALGORITHM = "HS256"
    JWT_EXPIRES_MINUTES = int(os.getenv("JWT_EXPIRES_MINUTES", "60"))

    # Server
    DEBUG = os.getenv("FLASK_DEBUG", "0") == "1"
    HOST = os.getenv("HOST", "127.0.0.1")
    PORT = int(os.getenv("PORT", "5000"))

    CORS_ORIGINS = [
        o.strip()
        for o in os.getenv(
            "CORS_ORIGINS", "http://127.0.0.1:5000,http://localhost:5000"
        ).split(",")
        if o.strip()
    ]

    TEMPLATE_DIR = str(PROJECT_DIR / "frontend" / "templates")
    STATIC_DIR = str(PROJECT_DIR / "frontend" / "static")
