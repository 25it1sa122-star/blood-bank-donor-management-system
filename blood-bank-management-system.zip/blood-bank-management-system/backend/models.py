"""Constants, input validation and serializers shared by all routes."""
import re
from datetime import date, datetime, timedelta
from decimal import Decimal

BLOOD_GROUPS = ["A+", "A-", "B+", "B-", "AB+", "AB-", "O+", "O-"]
URGENCY_LEVELS = ["Normal", "Urgent", "Critical"]
REQUEST_STATUSES = ["Pending", "Approved", "Rejected", "Fulfilled"]

# Allowed status transitions (admin). Fulfilled / Rejected are final.
STATUS_TRANSITIONS = {
    "Pending": {"Approved", "Rejected"},
    "Approved": {"Fulfilled", "Rejected"},
    "Rejected": set(),
    "Fulfilled": set(),
}

DONATION_GAP_DAYS = 90  # minimum days between whole-blood donations

EMAIL_RE = re.compile(r"^[A-Za-z0-9._%+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,}$")
NAME_RE = re.compile(r"^[A-Za-z][A-Za-z .'\-]{1,99}$")
PHONE_RE = re.compile(r"^\+?[0-9]{10,15}$")


class ValidationError(Exception):
    def __init__(self, errors):
        super().__init__("Validation failed")
        self.errors = errors  # {field: message}


# ---------------------------------------------------------------- normalizers
def normalize_blood_group(value):
    if value is None:
        return None
    v = str(value).strip().upper().replace(" ", "+")
    return v if v in BLOOD_GROUPS else None


def _clean(value):
    return value.strip() if isinstance(value, str) else value


def parse_date(value):
    if isinstance(value, date):
        return value
    return datetime.strptime(str(value).strip(), "%Y-%m-%d").date()


# ---------------------------------------------------------------- validators
def validate_donor_fields(data, partial=False):
    """Validate donor profile fields. With partial=True only supplied keys are checked.
    Returns a cleaned dict containing only validated keys."""
    errors, out = {}, {}

    def present(key):
        return key in data

    def required(key):
        if partial:
            return present(key)
        return True

    # full_name
    if required("full_name"):
        v = _clean(data.get("full_name") or "")
        if not NAME_RE.match(v):
            errors["full_name"] = "Enter a valid full name (2-100 letters, spaces, . ' -)."
        else:
            out["full_name"] = v

    # email
    if required("email"):
        v = _clean(data.get("email") or "").lower()
        if not EMAIL_RE.match(v) or len(v) > 120:
            errors["email"] = "Enter a valid email address."
        else:
            out["email"] = v

    # phone
    if required("phone"):
        raw = _clean(data.get("phone") or "")
        v = re.sub(r"[\s\-()]", "", raw)
        if not PHONE_RE.match(v):
            errors["phone"] = "Enter a valid phone number (10-15 digits, optional leading +)."
        else:
            out["phone"] = v

    # blood group
    if required("blood_group"):
        v = normalize_blood_group(data.get("blood_group"))
        if not v:
            errors["blood_group"] = "Choose a valid blood group."
        else:
            out["blood_group"] = v

    # city
    if required("city"):
        v = _clean(data.get("city") or "")
        if not (2 <= len(v) <= 80):
            errors["city"] = "City must be 2-80 characters."
        else:
            out["city"] = v

    # address
    if required("address"):
        v = _clean(data.get("address") or "")
        if not (5 <= len(v) <= 255):
            errors["address"] = "Address must be 5-255 characters."
        else:
            out["address"] = v

    # age
    if required("age"):
        try:
            v = int(data.get("age"))
            if isinstance(data.get("age"), bool) or not (18 <= v <= 65):
                raise ValueError
            out["age"] = v
        except (TypeError, ValueError):
            errors["age"] = "Age must be a whole number between 18 and 65."

    # last donation date (optional)
    if present("last_donation_date"):
        raw = data.get("last_donation_date")
        if raw in (None, ""):
            out["last_donation_date"] = None
        else:
            try:
                d = parse_date(raw)
                if d > date.today():
                    errors["last_donation_date"] = "Last donation date cannot be in the future."
                elif d < date(1990, 1, 1):
                    errors["last_donation_date"] = "Enter a realistic last donation date."
                else:
                    out["last_donation_date"] = d
            except ValueError:
                errors["last_donation_date"] = "Use the format YYYY-MM-DD."

    # availability (optional)
    if present("is_available"):
        v = data.get("is_available")
        if isinstance(v, bool):
            out["is_available"] = v
        elif str(v).lower() in ("1", "true", "yes", "on"):
            out["is_available"] = True
        elif str(v).lower() in ("0", "false", "no", "off"):
            out["is_available"] = False
        else:
            errors["is_available"] = "Availability must be true or false."

    if errors:
        raise ValidationError(errors)
    return out


def validate_password(password):
    if not isinstance(password, str) or len(password) < 8 or len(password) > 128:
        raise ValidationError({"password": "Password must be 8-128 characters."})
    if not re.search(r"[A-Za-z]", password) or not re.search(r"[0-9]", password):
        raise ValidationError({"password": "Password must contain at least one letter and one number."})
    return password


def validate_request_fields(data):
    errors, out = {}, {}

    v = _clean(data.get("patient_name") or "")
    if not NAME_RE.match(v):
        errors["patient_name"] = "Enter a valid patient name."
    else:
        out["patient_name"] = v

    v = normalize_blood_group(data.get("blood_group"))
    if not v:
        errors["blood_group"] = "Choose the required blood group."
    else:
        out["blood_group"] = v

    try:
        units = int(data.get("units"))
        if isinstance(data.get("units"), bool) or not (1 <= units <= 20):
            raise ValueError
        out["units"] = units
    except (TypeError, ValueError):
        errors["units"] = "Units must be a whole number between 1 and 20."

    v = _clean(data.get("hospital_name") or "")
    if not (3 <= len(v) <= 150):
        errors["hospital_name"] = "Hospital name must be 3-150 characters."
    else:
        out["hospital_name"] = v

    v = _clean(data.get("city") or "")
    if not (2 <= len(v) <= 80):
        errors["city"] = "City must be 2-80 characters."
    else:
        out["city"] = v

    raw = re.sub(r"[\s\-()]", "", _clean(data.get("contact_number") or ""))
    if not PHONE_RE.match(raw):
        errors["contact_number"] = "Enter a valid contact number (10-15 digits)."
    else:
        out["contact_number"] = raw

    v = _clean(data.get("urgency") or "Normal")
    if v not in URGENCY_LEVELS:
        errors["urgency"] = "Urgency must be Normal, Urgent or Critical."
    else:
        out["urgency"] = v

    raw = data.get("request_date")
    if raw in (None, ""):
        out["request_date"] = date.today()
    else:
        try:
            d = parse_date(raw)
            if d < date.today() or d > date.today() + timedelta(days=90):
                errors["request_date"] = "Request date must be between today and 90 days from now."
            else:
                out["request_date"] = d
        except ValueError:
            errors["request_date"] = "Use the format YYYY-MM-DD."

    if errors:
        raise ValidationError(errors)
    return out


# ---------------------------------------------------------------- serializers
def json_safe(value):
    if isinstance(value, (datetime, date)):
        return value.isoformat()
    if isinstance(value, Decimal):
        return int(value) if value == value.to_integral_value() else float(value)
    return value


def serialize(row):
    if row is None:
        return None
    return {k: json_safe(v) for k, v in row.items()}


def is_eligible(row):
    """Available and past the minimum gap since the last donation."""
    if not row.get("is_available"):
        return False
    last = row.get("last_donation_date")
    if not last:
        return True
    if isinstance(last, datetime):
        last = last.date()
    return (date.today() - last).days >= DONATION_GAP_DAYS


def serialize_donor(row, full=True):
    """full=False -> public view (no email, phone or street address)."""
    data = serialize(row)
    data["is_available"] = bool(row["is_available"])
    data["eligible"] = is_eligible(row)
    if not full:
        for key in ("email", "phone", "address", "user_id", "created_at", "updated_at", "age"):
            data.pop(key, None)
    return data


def serialize_request(row):
    return serialize(row)
