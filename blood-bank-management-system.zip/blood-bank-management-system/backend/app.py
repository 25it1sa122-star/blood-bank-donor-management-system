"""Blood Bank Management System - Flask application entry point.

Run from the backend folder:   python app.py
"""
import sys

from flask import Flask, jsonify, render_template, request
from flask_cors import CORS
from mysql.connector import Error as MySQLError

try:
    from config import Config, ConfigError
except Exception as exc:  # config.py raises ConfigError at import time if secrets are missing
    print(f"\n[SETUP ERROR] {exc}\n")
    sys.exit(1)

from database import DatabaseSetupError, check_connection, close_db, explain_error
from routes import admin, auth, blood_stock, donors
from routes import requests as requests_routes


def create_app():
    app = Flask(
        __name__,
        template_folder=Config.TEMPLATE_DIR,
        static_folder=Config.STATIC_DIR,
        static_url_path="/static",
    )
    app.config["SECRET_KEY"] = Config.SECRET_KEY
    app.config["JSON_SORT_KEYS"] = False
    app.config["MAX_CONTENT_LENGTH"] = 1024 * 1024  # 1 MB request bodies

    CORS(app, resources={r"/api/*": {"origins": Config.CORS_ORIGINS}},
         allow_headers=["Content-Type", "Authorization"],
         methods=["GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS"])

    app.teardown_appcontext(close_db)

    for module in (auth, donors, blood_stock, requests_routes, admin):
        app.register_blueprint(module.bp)

    # ------------------------------------------------------------ pages
    pages = {
        "/": ("index.html", "home"),
        "/login": ("login.html", "login"),
        "/register": ("register.html", "register"),
        "/donors": ("donors.html", "donors"),
        "/search-blood": ("search_blood.html", "search"),
        "/request-blood": ("request_blood.html", "request"),
        "/donor/dashboard": ("donor_dashboard.html", "donor-dashboard"),
        "/admin/dashboard": ("admin_dashboard.html", "admin-dashboard"),
        "/admin/donors": ("manage_donors.html", "manage-donors"),
        "/admin/requests": ("manage_requests.html", "manage-requests"),
        "/admin/stock": ("blood_stock.html", "blood-stock"),
    }

    def make_view(template, page):
        def view():
            return render_template(template, page=page)
        view.__name__ = f"page_{page.replace('-', '_')}"
        return view

    for path, (template, page) in pages.items():
        app.add_url_rule(path, view_func=make_view(template, page))

    # ------------------------------------------------------------ health
    @app.get("/api/health")
    def health():
        ok, message = check_connection()
        return jsonify({"status": "ok" if ok else "error", "database": message}), (200 if ok else 503)

    # ------------------------------------------------------------ headers
    @app.after_request
    def security_headers(resp):
        resp.headers.setdefault("X-Content-Type-Options", "nosniff")
        resp.headers.setdefault("X-Frame-Options", "DENY")
        resp.headers.setdefault("Referrer-Policy", "same-origin")
        if request.path.startswith("/api/"):
            resp.headers["Cache-Control"] = "no-store"
        return resp

    # ------------------------------------------------------------ errors
    @app.errorhandler(DatabaseSetupError)
    def db_setup_error(err):
        return jsonify({"error": str(err), "setup_error": True}), 503

    @app.errorhandler(MySQLError)
    def db_error(err):
        app.logger.exception("MySQL error")
        if getattr(err, "errno", None) in (1146, 1049, 1045, 2003, 2013, 2006):
            return jsonify({"error": explain_error(err), "setup_error": True}), 503
        return jsonify({"error": "A database error occurred."}), 500

    @app.errorhandler(404)
    def not_found(_err):
        if request.path.startswith("/api/"):
            return jsonify({"error": "Endpoint not found."}), 404
        return render_template("index.html", page="home"), 404

    @app.errorhandler(405)
    def method_not_allowed(_err):
        return jsonify({"error": "Method not allowed."}), 405

    @app.errorhandler(413)
    def too_large(_err):
        return jsonify({"error": "Request body too large."}), 413

    @app.errorhandler(500)
    def server_error(_err):
        return jsonify({"error": "Internal server error."}), 500

    return app


app = create_app()


if __name__ == "__main__":
    ok, message = check_connection()
    if ok:
        print(f"[OK] {message}")
    else:
        print("\n" + "=" * 70)
        print("[DATABASE SETUP ERROR]")
        print(message)
        print("The website will start, but API calls will fail until this is fixed.")
        print("=" * 70 + "\n")
    print(f"Open http://{Config.HOST}:{Config.PORT} in your browser")
    app.run(host=Config.HOST, port=Config.PORT, debug=Config.DEBUG)
