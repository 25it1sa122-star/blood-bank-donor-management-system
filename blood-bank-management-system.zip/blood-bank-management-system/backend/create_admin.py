"""Create the initial administrator account securely.

Usage (from the backend folder, virtual environment active):
    python create_admin.py

The password is typed at a hidden prompt (or read from the ADMIN_PASSWORD
environment variable for scripted setups). It is hashed with Werkzeug and is
never written to disk or stored in plain text.
"""
import getpass
import os
import sys

from mysql.connector import Error as MySQLError
from werkzeug.security import generate_password_hash

try:
    from config import Config  # noqa: F401  (loads .env and validates secrets)
except Exception as exc:
    print(f"\n[SETUP ERROR] {exc}")
    sys.exit(1)

from database import DatabaseSetupError, new_connection
from models import EMAIL_RE, NAME_RE, ValidationError, validate_password


def main():
    print("=== Create administrator account ===")
    name = (os.getenv("ADMIN_NAME") or input("Full name: ")).strip()
    email = (os.getenv("ADMIN_EMAIL") or input("Email: ")).strip().lower()

    if not NAME_RE.match(name):
        sys.exit("Invalid name (2-100 letters, spaces, . ' -).")
    if not EMAIL_RE.match(email):
        sys.exit("Invalid email address.")

    password = os.getenv("ADMIN_PASSWORD")
    if not password:
        password = getpass.getpass("Password (min 8 chars, letters + numbers): ")
        if password != getpass.getpass("Confirm password: "):
            sys.exit("Passwords do not match.")
    try:
        validate_password(password)
    except ValidationError as err:
        sys.exit(err.errors["password"])

    try:
        conn = new_connection()
    except DatabaseSetupError as err:
        sys.exit(f"[DATABASE SETUP ERROR] {err}")

    try:
        cur = conn.cursor()
        cur.execute("SELECT id, role FROM users WHERE email = %s", (email,))
        existing = cur.fetchone()
        if existing:
            if existing[1] == "admin":
                sys.exit("An administrator with this email already exists.")
            answer = input("This email belongs to a donor account. Promote it to admin? [y/N]: ")
            if answer.strip().lower() != "y":
                sys.exit("Cancelled.")
            cur.execute("UPDATE users SET role = 'admin', password_hash = %s, is_active = 1 WHERE id = %s",
                        (generate_password_hash(password), existing[0]))
        else:
            cur.execute(
                "INSERT INTO users (full_name, email, password_hash, role) VALUES (%s, %s, %s, 'admin')",
                (name, email, generate_password_hash(password)),
            )
        print(f"Administrator ready: {email}")
        print("Log in at http://127.0.0.1:5000/login")
    except MySQLError as err:
        sys.exit(f"Database error: {err}")
    finally:
        conn.close()


if __name__ == "__main__":
    main()
