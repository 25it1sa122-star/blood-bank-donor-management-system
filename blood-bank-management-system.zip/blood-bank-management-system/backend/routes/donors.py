"""Donor CRUD. Public callers only ever see non-private fields of available donors."""
from flask import Blueprint, g, jsonify, request
from mysql.connector import IntegrityError

from database import execute, fetch_all, fetch_one, transaction
from middleware.auth import admin_required, jwt_optional, jwt_required
from models import (
    ValidationError,
    normalize_blood_group,
    serialize_donor,
    validate_donor_fields,
)

bp = Blueprint("donors", __name__, url_prefix="/api/donors")

DONOR_COLUMNS = (
    "id, user_id, full_name, email, phone, blood_group, city, address, age, "
    "last_donation_date, is_available, created_at, updated_at"
)


def _is_admin():
    return g.current_user is not None and g.current_user["role"] == "admin"


def _can_manage(donor):
    u = g.current_user
    return u is not None and (u["role"] == "admin" or donor["user_id"] == u["id"])


def _page_args():
    try:
        page = max(1, int(request.args.get("page", 1)))
        per_page = min(100, max(1, int(request.args.get("per_page", 20))))
    except ValueError:
        page, per_page = 1, 20
    return page, per_page


@bp.get("")
@jwt_optional
def list_donors():
    admin = _is_admin()
    where, params = [], []

    group = request.args.get("blood_group", "").strip()
    if group:
        g_norm = normalize_blood_group(group)
        if not g_norm:
            return jsonify({"error": "Unknown blood group."}), 400
        where.append("blood_group = %s")
        params.append(g_norm)

    location = request.args.get("city", "").strip() or request.args.get("location", "").strip()
    if location:
        where.append("(city LIKE %s OR (%s AND address LIKE %s))")
        like = f"%{location}%"
        params += [like, 1 if admin else 0, like]

    q = request.args.get("q", "").strip()
    if q:
        if admin:
            where.append("(full_name LIKE %s OR email LIKE %s OR phone LIKE %s)")
            params += [f"%{q}%"] * 3
        else:
            where.append("full_name LIKE %s")
            params.append(f"%{q}%")

    available = request.args.get("available", "").strip().lower()
    if not admin or available in ("1", "true"):
        where.append("is_available = 1")  # public callers never see unavailable donors
    elif available in ("0", "false"):
        where.append("is_available = 0")

    clause = ("WHERE " + " AND ".join(where)) if where else ""
    page, per_page = _page_args()

    total = fetch_one(f"SELECT COUNT(*) AS c FROM donors {clause}", params)["c"]
    rows = fetch_all(
        f"SELECT {DONOR_COLUMNS} FROM donors {clause} ORDER BY full_name LIMIT %s OFFSET %s",
        params + [per_page, (page - 1) * per_page],
    )
    return jsonify({
        "donors": [serialize_donor(r, full=admin) for r in rows],
        "total": total,
        "page": page,
        "per_page": per_page,
    })


@bp.get("/me")
@jwt_required
def my_profile():
    donor = fetch_one(f"SELECT {DONOR_COLUMNS} FROM donors WHERE user_id = %s", (g.current_user["id"],))
    if not donor:
        return jsonify({"error": "No donor profile is linked to this account."}), 404
    return jsonify({"donor": serialize_donor(donor)})


@bp.post("")
@admin_required
def create_donor():
    data = request.get_json(silent=True) or {}
    try:
        f = validate_donor_fields(data)
    except ValidationError as err:
        return jsonify({"error": "Please fix the highlighted fields.", "fields": err.errors}), 400
    try:
        new_id, _ = execute(
            """INSERT INTO donors (full_name, email, phone, blood_group, city, address, age,
                                   last_donation_date, is_available)
               VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s)""",
            (f["full_name"], f["email"], f["phone"], f["blood_group"], f["city"], f["address"],
             f["age"], f.get("last_donation_date"), f.get("is_available", True)),
        )
    except IntegrityError:
        return jsonify({"error": "A donor with this email already exists.",
                        "fields": {"email": "This email is already registered."}}), 409
    donor = fetch_one(f"SELECT {DONOR_COLUMNS} FROM donors WHERE id = %s", (new_id,))
    return jsonify({"message": "Donor added.", "donor": serialize_donor(donor)}), 201


@bp.get("/<int:donor_id>")
@jwt_required
def get_donor(donor_id):
    donor = fetch_one(f"SELECT {DONOR_COLUMNS} FROM donors WHERE id = %s", (donor_id,))
    if not donor:
        return jsonify({"error": "Donor not found."}), 404
    if not _can_manage(donor):
        return jsonify({"error": "You do not have permission to view this donor."}), 403
    return jsonify({"donor": serialize_donor(donor)})


@bp.put("/<int:donor_id>")
@jwt_required
def update_donor(donor_id):
    donor = fetch_one(f"SELECT {DONOR_COLUMNS} FROM donors WHERE id = %s", (donor_id,))
    if not donor:
        return jsonify({"error": "Donor not found."}), 404
    if not _can_manage(donor):
        return jsonify({"error": "You do not have permission to edit this donor."}), 403

    data = request.get_json(silent=True) or {}
    allowed = {k: v for k, v in data.items() if k in {
        "full_name", "email", "phone", "blood_group", "city", "address", "age",
        "last_donation_date", "is_available"}}
    if not allowed:
        return jsonify({"error": "No valid fields were provided."}), 400
    try:
        f = validate_donor_fields(allowed, partial=True)
    except ValidationError as err:
        return jsonify({"error": "Please fix the highlighted fields.", "fields": err.errors}), 400

    sets = ", ".join(f"{col} = %s" for col in f)  # column names come from the validated whitelist
    try:
        with transaction() as cur:
            cur.execute(f"UPDATE donors SET {sets} WHERE id = %s", [*f.values(), donor_id])
            if donor["user_id"] and ("email" in f or "full_name" in f):
                cur.execute(
                    "UPDATE users SET email = COALESCE(%s, email), full_name = COALESCE(%s, full_name) WHERE id = %s",
                    (f.get("email"), f.get("full_name"), donor["user_id"]),
                )
    except IntegrityError:
        return jsonify({"error": "That email is already used by another account.",
                        "fields": {"email": "This email is already registered."}}), 409

    updated = fetch_one(f"SELECT {DONOR_COLUMNS} FROM donors WHERE id = %s", (donor_id,))
    return jsonify({"message": "Donor profile updated.", "donor": serialize_donor(updated)})


@bp.delete("/<int:donor_id>")
@jwt_required
def delete_donor(donor_id):
    donor = fetch_one("SELECT id, user_id FROM donors WHERE id = %s", (donor_id,))
    if not donor:
        return jsonify({"error": "Donor not found."}), 404
    if not _can_manage(donor):
        return jsonify({"error": "You do not have permission to delete this donor."}), 403

    with transaction() as cur:
        cur.execute("DELETE FROM donors WHERE id = %s", (donor_id,))
        if donor["user_id"]:
            # remove the donor's login too (never an admin: donors.user_id only links donor accounts)
            cur.execute("DELETE FROM users WHERE id = %s AND role = 'donor'", (donor["user_id"],))
    return jsonify({"message": "Donor record deleted."})
