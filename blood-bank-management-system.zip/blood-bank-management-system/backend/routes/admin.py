"""Admin dashboard statistics (all values come from the database)."""
from flask import Blueprint, jsonify

from database import fetch_all, fetch_one
from middleware.auth import admin_required
from models import BLOOD_GROUPS, REQUEST_STATUSES, serialize, serialize_request

bp = Blueprint("admin", __name__, url_prefix="/api/admin")


@bp.get("/stats")
@admin_required
def stats():
    donors = fetch_one(
        "SELECT COUNT(*) AS total, COALESCE(SUM(is_available),0) AS available FROM donors")
    units = fetch_one("SELECT COALESCE(SUM(units),0) AS total FROM blood_stock")["total"]

    counts = {s: 0 for s in REQUEST_STATUSES}
    for r in fetch_all("SELECT status, COUNT(*) AS c FROM blood_requests GROUP BY status"):
        counts[r["status"]] = r["c"]

    stock = fetch_all("SELECT blood_group, units FROM blood_stock")
    stock.sort(key=lambda r: BLOOD_GROUPS.index(r["blood_group"]))

    recent = fetch_all(
        """SELECT id, patient_name, blood_group, units, hospital_name, city, urgency, status,
                  request_date, created_at
           FROM blood_requests ORDER BY created_at DESC, id DESC LIMIT 8""")

    donors_by_group = {g: 0 for g in BLOOD_GROUPS}
    for r in fetch_all("SELECT blood_group, COUNT(*) AS c FROM donors GROUP BY blood_group"):
        donors_by_group[r["blood_group"]] = r["c"]

    requests_by_group = {g: 0 for g in BLOOD_GROUPS}
    for r in fetch_all("SELECT blood_group, COUNT(*) AS c FROM blood_requests GROUP BY blood_group"):
        requests_by_group[r["blood_group"]] = r["c"]

    top_cities = fetch_all(
        "SELECT city, COUNT(*) AS donors FROM donors GROUP BY city ORDER BY donors DESC, city LIMIT 5")

    units_fulfilled = fetch_one(
        "SELECT COALESCE(SUM(units),0) AS u FROM blood_requests WHERE status = 'Fulfilled'")["u"]

    monthly = fetch_all(
        """SELECT DATE_FORMAT(created_at, '%Y-%m') AS month, COUNT(*) AS requests
           FROM blood_requests
           WHERE created_at >= DATE_SUB(CURDATE(), INTERVAL 5 MONTH) - INTERVAL (DAY(CURDATE()) - 1) DAY
           GROUP BY month ORDER BY month""")

    low_stock = [r["blood_group"] for r in stock if r["units"] < 5]

    return jsonify({
        "total_donors": donors["total"],
        "available_donors": int(donors["available"]),
        "total_units": int(units),
        "pending_requests": counts["Pending"],
        "approved_requests": counts["Approved"],
        "rejected_requests": counts["Rejected"],
        "fulfilled_requests": counts["Fulfilled"],
        "total_requests": sum(counts.values()),
        "stock": [serialize(r) for r in stock],
        "low_stock_groups": low_stock,
        "recent_requests": [serialize_request(r) for r in recent],
        "reports": {
            "donors_by_group": donors_by_group,
            "requests_by_group": requests_by_group,
            "top_cities": [serialize(r) for r in top_cities],
            "units_fulfilled": int(units_fulfilled),
            "monthly_requests": [serialize(r) for r in monthly],
        },
    })
