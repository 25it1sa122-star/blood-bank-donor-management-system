"""Blood requests: submit, list, status workflow (stock is deducted exactly once, on Fulfilled)."""
from flask import Blueprint, g, jsonify, request

from database import execute, fetch_all, fetch_one, transaction
from middleware.auth import admin_required, jwt_optional, jwt_required
from models import (
    REQUEST_STATUSES,
    STATUS_TRANSITIONS,
    ValidationError,
    normalize_blood_group,
    serialize_request,
    validate_request_fields,
)

bp = Blueprint("requests", __name__, url_prefix="/api/requests")

COLUMNS = (
    "id, requester_user_id, patient_name, blood_group, units, hospital_name, city, "
    "contact_number, urgency, request_date, status, admin_note, fulfilled_at, created_at, updated_at"
)


@bp.post("")
@jwt_optional
def create_request():
    data = request.get_json(silent=True) or {}
    try:
        f = validate_request_fields(data)
    except ValidationError as err:
        return jsonify({"error": "Please fix the highlighted fields.", "fields": err.errors}), 400

    user = g.current_user
    new_id, _ = execute(
        """INSERT INTO blood_requests
           (requester_user_id, patient_name, blood_group, units, hospital_name, city,
            contact_number, urgency, request_date, status)
           VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,'Pending')""",
        (user["id"] if user else None, f["patient_name"], f["blood_group"], f["units"],
         f["hospital_name"], f["city"], f["contact_number"], f["urgency"], f["request_date"]),
    )
    row = fetch_one(f"SELECT {COLUMNS} FROM blood_requests WHERE id = %s", (new_id,))
    return jsonify({"message": "Your blood request has been submitted and is pending review.",
                    "request": serialize_request(row)}), 201


@bp.get("")
@jwt_required
def list_requests():
    user = g.current_user
    where, params = [], []

    if user["role"] != "admin":  # donors only ever see requests they submitted
        where.append("requester_user_id = %s")
        params.append(user["id"])

    status = request.args.get("status", "").strip()
    if status:
        if status not in REQUEST_STATUSES:
            return jsonify({"error": "Unknown status."}), 400
        where.append("status = %s")
        params.append(status)

    group = request.args.get("blood_group", "").strip()
    if group:
        norm = normalize_blood_group(group)
        if not norm:
            return jsonify({"error": "Unknown blood group."}), 400
        where.append("blood_group = %s")
        params.append(norm)

    q = request.args.get("q", "").strip()
    if q:
        where.append("(patient_name LIKE %s OR hospital_name LIKE %s OR city LIKE %s)")
        params += [f"%{q}%"] * 3

    clause = ("WHERE " + " AND ".join(where)) if where else ""
    try:
        page = max(1, int(request.args.get("page", 1)))
        per_page = min(100, max(1, int(request.args.get("per_page", 20))))
    except ValueError:
        page, per_page = 1, 20

    total = fetch_one(f"SELECT COUNT(*) AS c FROM blood_requests {clause}", params)["c"]
    rows = fetch_all(
        f"""SELECT {COLUMNS} FROM blood_requests {clause}
            ORDER BY FIELD(status,'Pending','Approved','Fulfilled','Rejected'),
                     FIELD(urgency,'Critical','Urgent','Normal'), created_at DESC
            LIMIT %s OFFSET %s""",
        params + [per_page, (page - 1) * per_page],
    )
    return jsonify({"requests": [serialize_request(r) for r in rows],
                    "total": total, "page": page, "per_page": per_page})


@bp.get("/<int:req_id>")
@jwt_required
def get_request(req_id):
    row = fetch_one(f"SELECT {COLUMNS} FROM blood_requests WHERE id = %s", (req_id,))
    if not row:
        return jsonify({"error": "Request not found."}), 404
    user = g.current_user
    if user["role"] != "admin" and row["requester_user_id"] != user["id"]:
        return jsonify({"error": "You do not have permission to view this request."}), 403
    return jsonify({"request": serialize_request(row)})


@bp.patch("/<int:req_id>/status")
@admin_required
def update_status(req_id):
    data = request.get_json(silent=True) or {}
    new_status = str(data.get("status") or "").strip().capitalize()
    if new_status not in REQUEST_STATUSES or new_status == "Pending":
        return jsonify({"error": "Status must be Approved, Rejected or Fulfilled."}), 400

    note = data.get("admin_note")
    if note is not None:
        note = str(note).strip()[:255] or None

    warning = None
    with transaction() as cur:
        # Lock the request row so two admins cannot process it at the same time.
        cur.execute(f"SELECT {COLUMNS} FROM blood_requests WHERE id = %s FOR UPDATE", (req_id,))
        row = cur.fetchone()
        if not row:
            return jsonify({"error": "Request not found."}), 404

        current = row["status"]
        if new_status not in STATUS_TRANSITIONS[current]:
            allowed = ", ".join(sorted(STATUS_TRANSITIONS[current])) or "none (final status)"
            return jsonify({"error": f"A {current} request cannot be changed to {new_status}. "
                                     f"Allowed: {allowed}."}), 409

        if new_status == "Fulfilled":
            # Lock the stock row, validate, then deduct. The status check above, done while
            # holding the request lock, guarantees this runs at most once per request.
            cur.execute("SELECT units FROM blood_stock WHERE blood_group = %s FOR UPDATE",
                        (row["blood_group"],))
            stock = cur.fetchone()
            available = stock["units"] if stock else 0
            if available < row["units"]:
                return jsonify({
                    "error": f"Insufficient stock: {row['units']} unit(s) of {row['blood_group']} "
                             f"requested but only {available} available.",
                    "available": available,
                }), 409
            cur.execute("UPDATE blood_stock SET units = units - %s WHERE blood_group = %s AND units >= %s",
                        (row["units"], row["blood_group"], row["units"]))
            if cur.rowcount != 1:
                return jsonify({"error": "Stock changed while processing. Please retry."}), 409
            cur.execute(
                "UPDATE blood_requests SET status = 'Fulfilled', fulfilled_at = NOW(), "
                "admin_note = COALESCE(%s, admin_note) WHERE id = %s",
                (note, req_id),
            )
        else:
            if new_status == "Approved":
                cur.execute("SELECT units FROM blood_stock WHERE blood_group = %s", (row["blood_group"],))
                stock = cur.fetchone()
                if stock and stock["units"] < row["units"]:
                    warning = (f"Only {stock['units']} unit(s) of {row['blood_group']} are in stock "
                               f"right now; {row['units']} needed. Add stock before fulfilling.")
            cur.execute("UPDATE blood_requests SET status = %s, admin_note = COALESCE(%s, admin_note) "
                        "WHERE id = %s", (new_status, note, req_id))

    updated = fetch_one(f"SELECT {COLUMNS} FROM blood_requests WHERE id = %s", (req_id,))
    resp = {"message": f"Request marked as {new_status}.", "request": serialize_request(updated)}
    if new_status == "Fulfilled":
        resp["message"] = f"Request fulfilled. {row['units']} unit(s) of {row['blood_group']} deducted from stock."
    if warning:
        resp["warning"] = warning
    return jsonify(resp)
