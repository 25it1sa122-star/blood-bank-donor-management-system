"""Authentication: register (donor), login, current user."""
import time
from collections import defaultdict

from flask import Blueprint, g, jsonify, request
from mysql.connector import IntegrityError
from werkzeug.security import check_password_hash, generate_password_hash

from database import fetch_one, transaction
from middleware.auth import create_token, jwt_required
from models import ValidationError, validate_donor_fields, validate_password

bp = Blueprint("auth", __name__, url_prefix="/api/auth")

# Very small in-memory login throttle: 10 failed attempts / 15 minutes per IP + email.
_FAILED = defaultdict(list)
_WINDOW, _MAX_FAILS = 15 * 60, 10
# A real hash to compare against when the email is unknown (keeps timing similar).
_DUMMY_HASH = generate_password_hash("not-a-real-password")


def _throttle_key(email):
    return f"{request.remote_addr}|{email}"


def _recent_failures(key):
    now = time.time()
    _FAILED[key] = [t for t in _FAILED[key] if now - t < _WINDOW]
    return len(_FAILED[key])


def _public_user(user):
    return {
        "id": user["id"],
        "full_name": user["full_name"],
        "email": user["email"],
        "role": user["role"],
    }


@bp.post("/register")
def register():
    data = request.get_json(silent=True) or {}
    try:
        fields = validate_donor_fields(data)
        password = validate_password(data.get("password"))
    except ValidationError as err:
        return jsonify({"error": "Please fix the highlighted fields.", "fields": err.errors}), 400

    try:
        with transaction() as cur:
            cur.execute(
                "INSERT INTO users (full_name, email, password_hash, role) VALUES (%s, %s, %s, 'donor')",
                (fields["full_name"], fields["email"], generate_password_hash(password)),
            )
            user_id = cur.lastrowid
            cur.execute(
                """INSERT INTO donors
                   (user_id, full_name, email, phone, blood_group, city, address, age,
                    last_donation_date, is_available)
                   VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)""",
                (
                    user_id,
                    fields["full_name"],
                    fields["email"],
                    fields["phone"],
                    fields["blood_group"],
                    fields["city"],
                    fields["address"],
                    fields["age"],
                    fields.get("last_donation_date"),
                    fields.get("is_available", True),
                ),
            )
    except IntegrityError:
        return jsonify({"error": "An account with this email already exists.",
                        "fields": {"email": "This email is already registered."}}), 409

    user = {"id": user_id, "full_name": fields["full_name"], "email": fields["email"], "role": "donor"}
    return jsonify({"message": "Registration successful.", "token": create_token(user),
                    "user": _public_user(user)}), 201


@bp.post("/login")
def login():
    data = request.get_json(silent=True) or {}
    email = str(data.get("email") or "").strip().lower()
    password = data.get("password")
    if not email or not isinstance(password, str) or not password:
        return jsonify({"error": "Email and password are required."}), 400

    key = _throttle_key(email)
    if _recent_failures(key) >= _MAX_FAILS:
        return jsonify({"error": "Too many failed attempts. Please try again in 15 minutes."}), 429

    user = fetch_one(
        "SELECT id, full_name, email, password_hash, role, is_active FROM users WHERE email = %s",
        (email,),
    )
    hash_to_check = user["password_hash"] if user else _DUMMY_HASH
    ok = check_password_hash(hash_to_check, password)
    if not user or not ok or not user["is_active"]:
        _FAILED[key].append(time.time())
        return jsonify({"error": "Invalid email or password."}), 401

    _FAILED.pop(key, None)
    return jsonify({"message": "Login successful.", "token": create_token(user),
                    "user": _public_user(user)})


@bp.get("/me")
@jwt_required
def me():
    user = dict(g.current_user)
    donor = fetch_one("SELECT id FROM donors WHERE user_id = %s", (user["id"],))
    out = _public_user(user)
    out["donor_id"] = donor["id"] if donor else None
    return jsonify({"user": out})
