"""Blood inventory. Public read, admin-only write."""
from flask import Blueprint, jsonify, request
from urllib.parse import unquote

from database import fetch_all, transaction
from middleware.auth import admin_required
from models import BLOOD_GROUPS, normalize_blood_group, serialize

bp = Blueprint("blood_stock", __name__, url_prefix="/api/blood-stock")

MAX_UNITS = 100000


def _all_stock():
    rows = fetch_all("SELECT blood_group, units, updated_at FROM blood_stock")
    order = {g: i for i, g in enumerate(BLOOD_GROUPS)}
    rows.sort(key=lambda r: order[r["blood_group"]])
    return [serialize(r) for r in rows]


@bp.get("")
def get_stock():
    stock = _all_stock()
    return jsonify({"stock": stock, "total_units": sum(r["units"] for r in stock)})


@bp.put("/<path:group>")
@admin_required
def update_stock(group):
    """Body: {"units": 20}  -> set absolute units
         or {"adjust": -3} -> add / remove units (never below zero)."""
    blood_group = normalize_blood_group(unquote(group))
    if not blood_group:
        return jsonify({"error": "Unknown blood group."}), 404

    data = request.get_json(silent=True) or {}
    has_units, has_adjust = "units" in data, "adjust" in data
    if has_units == has_adjust:
        return jsonify({"error": "Send either 'units' (set) or 'adjust' (add/remove)."}), 400

    key = "units" if has_units else "adjust"
    value = data[key]
    if isinstance(value, bool) or not isinstance(value, int):
        return jsonify({"error": f"'{key}' must be a whole number."}), 400

    with transaction() as cur:
        cur.execute("SELECT units FROM blood_stock WHERE blood_group = %s FOR UPDATE", (blood_group,))
        row = cur.fetchone()
        if row is None:
            return jsonify({"error": "Stock row not found. Re-import schema.sql."}), 500
        new_units = value if has_units else row["units"] + value
        if new_units < 0:
            return jsonify({"error": f"Stock cannot go below zero. {blood_group} currently has "
                                     f"{row['units']} unit(s)."}), 400
        if new_units > MAX_UNITS:
            return jsonify({"error": f"Units cannot exceed {MAX_UNITS}."}), 400
        cur.execute("UPDATE blood_stock SET units = %s WHERE blood_group = %s", (new_units, blood_group))

    return jsonify({"message": f"{blood_group} stock is now {new_units} unit(s).",
                    "blood_group": blood_group, "units": new_units})
