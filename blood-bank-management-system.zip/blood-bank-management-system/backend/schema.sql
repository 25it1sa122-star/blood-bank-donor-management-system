-- Blood Bank Management System - database schema (MySQL 8 / MariaDB 10.5+)
-- The database name contains hyphens, so it MUST be quoted with backticks.

CREATE DATABASE IF NOT EXISTS `blood-bank-management-system`
  CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

USE `blood-bank-management-system`;

-- ---------------------------------------------------------------- users
CREATE TABLE IF NOT EXISTS users (
  id            INT UNSIGNED NOT NULL AUTO_INCREMENT,
  full_name     VARCHAR(100) NOT NULL,
  email         VARCHAR(120) NOT NULL,
  password_hash VARCHAR(255) NOT NULL,
  role          ENUM('admin','donor') NOT NULL DEFAULT 'donor',
  is_active     TINYINT(1) NOT NULL DEFAULT 1,
  created_at    TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at    TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_users_email (email),
  KEY idx_users_role (role)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------- donors
-- user_id is NULL for donors added by an administrator who have no login.
CREATE TABLE IF NOT EXISTS donors (
  id                 INT UNSIGNED NOT NULL AUTO_INCREMENT,
  user_id            INT UNSIGNED NULL,
  full_name          VARCHAR(100) NOT NULL,
  email              VARCHAR(120) NOT NULL,
  phone              VARCHAR(20)  NOT NULL,
  blood_group        ENUM('A+','A-','B+','B-','AB+','AB-','O+','O-') NOT NULL,
  city               VARCHAR(80)  NOT NULL,
  address            VARCHAR(255) NOT NULL,
  age                TINYINT UNSIGNED NOT NULL,
  last_donation_date DATE NULL,
  is_available       TINYINT(1) NOT NULL DEFAULT 1,
  created_at         TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at         TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_donors_email (email),
  UNIQUE KEY uq_donors_user (user_id),
  KEY idx_donors_group_city (blood_group, city),
  KEY idx_donors_available (is_available),
  CONSTRAINT fk_donors_user FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE,
  CONSTRAINT chk_donors_age CHECK (age BETWEEN 18 AND 65)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------- blood_stock
-- Exactly one row per blood group. units can never go negative.
CREATE TABLE IF NOT EXISTS blood_stock (
  blood_group ENUM('A+','A-','B+','B-','AB+','AB-','O+','O-') NOT NULL,
  units       INT UNSIGNED NOT NULL DEFAULT 0,
  updated_at  TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (blood_group),
  CONSTRAINT chk_stock_units CHECK (units >= 0)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT IGNORE INTO blood_stock (blood_group, units) VALUES
  ('A+',0),('A-',0),('B+',0),('B-',0),('AB+',0),('AB-',0),('O+',0),('O-',0);

-- ---------------------------------------------------------------- blood_requests
CREATE TABLE IF NOT EXISTS blood_requests (
  id                INT UNSIGNED NOT NULL AUTO_INCREMENT,
  requester_user_id INT UNSIGNED NULL,
  patient_name      VARCHAR(100) NOT NULL,
  blood_group       ENUM('A+','A-','B+','B-','AB+','AB-','O+','O-') NOT NULL,
  units             TINYINT UNSIGNED NOT NULL,
  hospital_name     VARCHAR(150) NOT NULL,
  city              VARCHAR(80)  NOT NULL,
  contact_number    VARCHAR(20)  NOT NULL,
  urgency           ENUM('Normal','Urgent','Critical') NOT NULL DEFAULT 'Normal',
  request_date      DATE NOT NULL,
  status            ENUM('Pending','Approved','Rejected','Fulfilled') NOT NULL DEFAULT 'Pending',
  admin_note        VARCHAR(255) NULL,
  fulfilled_at      DATETIME NULL,
  created_at        TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at        TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_requests_status (status),
  KEY idx_requests_group (blood_group),
  KEY idx_requests_requester (requester_user_id),
  KEY idx_requests_created (created_at),
  CONSTRAINT fk_requests_user FOREIGN KEY (requester_user_id) REFERENCES users (id) ON DELETE SET NULL,
  CONSTRAINT chk_requests_units CHECK (units BETWEEN 1 AND 20)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
