"""JWT creation / verification and role-based access decorators."""
from datetime import datetime, timedelta, timezone
from functools import wraps

import jwt
from flask import g, jsonify, request

from config import Config
from database import fetch_one


def create_token(user):
    now = datetime.now(timezone.utc)
    payload = {
        "sub": str(user["id"]),
        "role": user["role"],
        "iat": now,
        "exp": now + timedelta(minutes=Config.JWT_EXPIRES_MINUTES),
    }
    return jwt.encode(payload, Config.JWT_SECRET_KEY, algorithm=Config.JWT_ALGORITHM)


def _auth_error(message, status=401):
    resp = jsonify({"error": message})
    resp.status_code = status
    return resp


def _load_user_from_request():
    """Returns (user, error_response). user is None when no Authorization header is sent."""
    header = request.headers.get("Authorization", "")
    if not header:
        return None, None
    parts = header.split()
    if len(parts) != 2 or parts[0].lower() != "bearer":
        return None, _auth_error("Authorization header must be 'Bearer <token>'.")
    try:
        payload = jwt.decode(
            parts[1],
            Config.JWT_SECRET_KEY,
            algorithms=[Config.JWT_ALGORITHM],
            options={"require": ["exp", "sub"]},
        )
    except jwt.ExpiredSignatureError:
        return None, _auth_error("Your session has expired. Please log in again.")
    except jwt.InvalidTokenError:
        return None, _auth_error("Invalid authentication token.")

    # Re-check the user in the database so deleted / disabled accounts lose access at once.
    user = fetch_one(
        "SELECT id, full_name, email, role, is_active FROM users WHERE id = %s",
        (payload["sub"],),
    )
    if not user or not user["is_active"]:
        return None, _auth_error("Account not found or disabled.")
    return user, None


def jwt_optional(fn):
    """Attach g.current_user when a valid token is sent; None for anonymous callers."""

    @wraps(fn)
    def wrapper(*args, **kwargs):
        user, err = _load_user_from_request()
        if err is not None:
            return err
        g.current_user = user
        return fn(*args, **kwargs)

    return wrapper


def jwt_required(fn):
    @wraps(fn)
    def wrapper(*args, **kwargs):
        user, err = _load_user_from_request()
        if err is not None:
            return err
        if user is None:
            return _auth_error("Authentication required.")
        g.current_user = user
        return fn(*args, **kwargs)

    return wrapper


def roles_required(*roles):
    def decorator(fn):
        @wraps(fn)
        @jwt_required
        def wrapper(*args, **kwargs):
            if g.current_user["role"] not in roles:
                return _auth_error("You do not have permission to do this.", 403)
            return fn(*args, **kwargs)

        return wrapper

    return decorator


admin_required = roles_required("admin")
