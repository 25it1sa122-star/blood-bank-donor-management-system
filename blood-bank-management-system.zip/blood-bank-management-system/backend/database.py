"""MySQL access helpers (mysql-connector-python, parameterized queries only)."""
from contextlib import contextmanager

import mysql.connector
from flask import g
from mysql.connector import Error as MySQLError

from config import Config


class DatabaseSetupError(Exception):
    """Raised with a human-friendly message when MySQL cannot be used."""


def explain_error(err: MySQLError) -> str:
    errno = getattr(err, "errno", None)
    where = f"{Config.DB_HOST}:{Config.DB_PORT}"
    if errno in (2003, 2002, 2005, 2006, 2013):
        return (
            f"Cannot connect to MySQL at {where}. Make sure the MySQL service is running "
            f"and DB_HOST / DB_PORT in your .env file are correct."
        )
    if errno == 1045:
        return (
            f"MySQL rejected the login for user '{Config.DB_USER}'. "
            f"Check DB_USER and DB_PASSWORD in your .env file."
        )
    if errno == 1049:
        return (
            f"The database '{Config.DB_NAME}' does not exist. Import backend/schema.sql "
            f"(see README step 'Import schema.sql and seed.sql')."
        )
    if errno == 1146:
        return (
            "A required table is missing. Import backend/schema.sql into the database "
            "(see README)."
        )
    return f"MySQL error: {err}"


def new_connection():
    try:
        return mysql.connector.connect(
            host=Config.DB_HOST,
            port=Config.DB_PORT,
            user=Config.DB_USER,
            password=Config.DB_PASSWORD,
            database=Config.DB_NAME,
            charset="utf8mb4",
            connection_timeout=5,
            autocommit=True,
        )
    except MySQLError as err:
        raise DatabaseSetupError(explain_error(err)) from err


def get_db():
    """One connection per request, stored on flask.g."""
    if "db" not in g:
        g.db = new_connection()
    return g.db


def close_db(_exc=None):
    db = g.pop("db", None)
    if db is not None:
        try:
            db.close()
        except MySQLError:
            pass


def check_connection():
    """Used at start-up and by /api/health. Returns (ok, message)."""
    try:
        conn = new_connection()
        cur = conn.cursor()
        cur.execute("SELECT COUNT(*) FROM blood_stock")
        cur.fetchone()
        cur.close()
        conn.close()
        return True, "Database connection OK"
    except DatabaseSetupError as err:
        return False, str(err)
    except MySQLError as err:
        return False, explain_error(err)


def fetch_all(sql, params=None):
    cur = get_db().cursor(dictionary=True)
    try:
        cur.execute(sql, params) if params else cur.execute(sql)
        return cur.fetchall()
    finally:
        cur.close()


def fetch_one(sql, params=None):
    cur = get_db().cursor(dictionary=True)
    try:
        cur.execute(sql, params) if params else cur.execute(sql)
        return cur.fetchone()
    finally:
        cur.close()


def execute(sql, params=None):
    """Run a write statement (autocommit). Returns (lastrowid, rowcount)."""
    cur = get_db().cursor()
    try:
        cur.execute(sql, params) if params else cur.execute(sql)
        return cur.lastrowid, cur.rowcount
    finally:
        cur.close()


@contextmanager
def transaction():
    """Explicit transaction. Yields a dict cursor; commits on success, rolls back on error."""
    conn = get_db()
    conn.start_transaction()
    cur = conn.cursor(dictionary=True)
    try:
        yield cur
        conn.commit()
    except BaseException:
        conn.rollback()
        raise
    finally:
        cur.close()
